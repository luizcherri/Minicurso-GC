/** ----------------------------------------------------------------------------
Minicurso: Implementação de geração de colunas usando CPLEX em linguagem C/C++
Descricao: modelo inteiro do problema de dimensionamento de lotes capacitado
com múltiplos itens (PDL)
Autores: Landir Saviniec e Luiz Henrique Cherri
-----------------------------------------------------------------------------**/

#include <iostream>
#include <vector>
#include <pthread.h>
#include <ilcplex/ilocplex.h>

int N_ITENS;
int N_PERIODOS;
std::vector<double> Capacidade;
std::vector<double> TempoProducao;
std::vector<double> CustoEstoque;
std::vector<double> TempoSetup;
std::vector<double> CustoSetup;
std::vector<std::vector<double>> Demanda;
std::vector<std::vector<double>> M;
class Subproblema;
class Mestre;

class Modelo
{
    public:
        IloEnv env;
        IloModel model;
        IloCplex cplex;
        IloObjective objective;

        //construtores
        Modelo(){
            env = IloEnv();
            model = IloModel(env);
            cplex = IloCplex(env);
        }

        ~Modelo(){
            model.end();
            cplex.end();
            env.end();
        }

        //metodos
        void setStream(std::ostream& st){
            cplex.setOut(st);
        }

        void setStreamOff(){
            cplex.setOut(env.getNullStream());
        }

        void solve(){
            cplex.solve();
        }

        IloNum getObjective(){
            return cplex.getObjValue();
        }

        IloCplex::CplexStatus getStatus(){
            return this->cplex.getCplexStatus();
        }
};

class ModeloInteiro : public Modelo
{
	public:

        IloArray<IloNumVarArray> X;
        IloArray<IloNumVarArray> E;
        IloArray<IloNumVarArray> Y;

        //construtores
        ModeloInteiro(){
            this->objective = IloMinimize(this->env);

            this->criar_modelo();

            this->model.add(this->objective);
            this->cplex.extract(this->model);
        }
        
        ~ModeloInteiro(){};

        //metodos
        void criar_modelo(){

            //define as variaveis do modelo
            X = IloArray<IloNumVarArray>(this->env, N_ITENS);
            E = IloArray<IloNumVarArray>(this->env, N_ITENS);
            Y = IloArray<IloNumVarArray>(this->env, N_ITENS);

            IloExpr funcObj(this->env);
            for(auto i=0; i<N_ITENS; i++){
                X[i] = IloNumVarArray(this->env, N_PERIODOS);
                E[i] = IloNumVarArray(this->env, N_PERIODOS);
                Y[i] = IloNumVarArray(this->env, N_PERIODOS);

                for(auto t=0; t<N_PERIODOS; t++){
                    X[i][t] = IloNumVar(this->env, 0, IloInfinity, ILOFLOAT);
                    E[i][t] = IloNumVar(this->env, 0, IloInfinity, ILOFLOAT);
                    Y[i][t] = IloNumVar(this->env, 0, 1, ILOFLOAT);

                    funcObj += CustoSetup[i] * Y[i][t] + CustoEstoque[i] * E[i][t];
                }
            }
            this->objective.setExpr(funcObj);  //funcao objectivo

            //define as restricoes
            for(auto i=0; i<N_ITENS; i++){
                for(auto t=0; t<N_PERIODOS; t++){
                    //conservacao de estoque
                    if(t==0){
                        this->model.add(E[i][t] == X[i][t] - Demanda[i][t]);
                    }else{
                        this->model.add(E[i][t] == E[i][t-1] + X[i][t] - Demanda[i][t]);
                    }

                    //o lote e limitado pela capacidade ou demanda dos periodos restantes
                    this->model.add(X[i][t] <= M[i][t] * Y[i][t]);
                }
            }

            //limite de capacidade
            IloExpr expr(this->env);
            for(auto t=0; t<N_PERIODOS; t++){
                expr.clear();
                for(auto i=0; i<N_ITENS; i++){
                    expr += TempoSetup[i] * Y[i][t] + TempoProducao[i] * X[i][t];
                }
                this->model.add(expr <= Capacidade[t]);
            }
            expr.end();
        }

        void converter_y_para_inteiro(){

            for(auto i=0; i<N_ITENS; i++){
                for(auto t=0; t<N_PERIODOS; t++){
                    this->model.add(IloConversion(this->env, Y[i][t], ILOBOOL));
                }
            }
        }
};

void ler_dados(std::string arquivo){

    std::ifstream in(arquivo.c_str());

    in >> N_ITENS;
    std::cout << "Numero de itens: " << N_ITENS << std::endl;

    in >> N_PERIODOS;
    std::cout << "Numero de periodos: " << N_PERIODOS << std::endl;

    double aux;
    in >> aux;
    in >> aux;

//    std::cout << "Capacidade:" << std::endl;
    for(auto i=0; i<N_PERIODOS; i++){
        Capacidade.push_back(aux);
//        std::cout << " " << Capacidade[i];
    }

//    std::cout << "\nTempo de producao:" << std::endl;
    for(auto i=0; i<N_ITENS; i++){
        in >> aux;
        TempoProducao.push_back(aux);
//        std::cout << " " << TempoProducao[i];
    }

//    std::cout << "\nCusto de estoque:" << std::endl;
    for(auto i=0; i<N_ITENS; i++){
        in >> aux;
        CustoEstoque.push_back(aux);
//        std::cout << " " << CustoEstoque[i];
    }

//    std::cout << "\nTempo de setup:" << std::endl;
    for(auto i=0; i<N_ITENS; i++){
        in >> aux;
        TempoSetup.push_back(aux);
//        std::cout << " " << TempoSetup[i];
    }

//    std::cout << "\nCusto de setup:" << std::endl;
    for(auto i=0; i<N_ITENS; i++){
        in >> aux;
        CustoSetup.push_back(aux);
//        std::cout << " " << CustoSetup[i];
    }

//    std::cout << "\nDemanda:" << std::endl;
    for(auto i=0; i<N_ITENS; i++){
        Demanda.push_back(std::vector<double>(N_PERIODOS, 0));
    }

    for(auto t=0; t<N_PERIODOS; t++){
        for(auto i=0; i<N_ITENS; i++){
            in >> Demanda[i][t];
//            std::cout << " " << Demanda[i][t];
        }
//        std::cout << std::endl;
    }

    //calcula M
    for(auto i=0; i<N_ITENS; i++){
        M.push_back(std::vector<double>(N_PERIODOS, 0));
        for(auto t=0; t<N_PERIODOS; t++){
            double soma = 0;
            for(auto j=t; j<N_PERIODOS; j++){
                soma += Demanda[i][j];
            }
            double x = (Capacidade[t] - TempoSetup[i]) / TempoProducao[i];
            M[i][t] = std::min(x, soma);
        }
    }
    std::cout << std::endl;
}

int main(int argc, char* argv[]){

    if(argc != 2){
        std::cout << "Argumento invalido." << std::endl;
        return 0;
    }

    ler_dados(argv[1]);

    ModeloInteiro modelo;
//    modelo.setStreamOff();

    modelo.solve();  //resolver a relaxacao linear
    double rl = modelo.getObjective();  //relaxacao linear
    modelo.converter_y_para_inteiro();
    modelo.solve();  //resolver o problema inteiro

    std::cout << "\n== Resultado ==================" << std::endl;
    std::cout << "Modelo status = " << modelo.getStatus() << std::endl;

    double ub = modelo.getObjective();
    double gap_rl = 100 * (ub - rl) / ub;

    std::cout << std::setprecision(10) << "UB = " << ub << std::endl;
    std::cout << std::setprecision(10) << "RL = " << rl << "  Gap = " << gap_rl << std::endl;
    
    return 0;
}
